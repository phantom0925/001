#!/bin/bash 

echo "Hello, $LOGNAME" 
echo "Current date is `date`" 
echo "User is `who i am`" 
echo "Current directory `pwd`"
